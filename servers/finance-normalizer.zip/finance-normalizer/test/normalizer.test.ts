import { describe, it, expect } from 'vitest';
import { normalizeTransactionsFromCsv } from '../src/index.js';

describe('normalizeTransactionsFromCsv', () => {
    it('should parse a basic CSV correctly', () => {
        const csv = `Date,Description,Amount,Currency
2023-01-01,Test Transaction,100.50,EUR
2023-01-02,Another One,-50.00,EUR`;

        const result = normalizeTransactionsFromCsv(csv);

        expect(result).toHaveLength(2);

        expect(result[0]).toMatchObject({
            date: '2023-01-01',
            description: 'Test Transaction',
            amount: 100.50,
            direction: 'credit',
            currency: 'EUR',
            raw_line_number: 2
        });

        expect(result[1]).toMatchObject({
            date: '2023-01-02',
            description: 'Another One',
            amount: 50.00,
            direction: 'debit',
            currency: 'EUR',
            raw_line_number: 3
        });
    });

    it('should use default currency if missing in CSV', () => {
        const csv = `Date,Description,Amount
2023-01-01,No Currency,100`;

        const result = normalizeTransactionsFromCsv(csv, { defaultCurrency: 'USD' });

        expect(result[0].currency).toBe('USD');
        expect(result[0].normalisation_notes).toContain('Used default currency: USD');
    });

    it('should mark currency as UNKNOWN if missing and no default', () => {
        const csv = `Date,Description,Amount
2023-01-01,No Currency,100`;

        const result = normalizeTransactionsFromCsv(csv);

        expect(result[0].currency).toBe('UNKNOWN');
        expect(result[0].normalisation_notes).toContain('Missing currency and no default provided');
    });

    it('should handle invalid amounts gracefully', () => {
        const csv = `Date,Description,Amount
2023-01-01,Bad Amount,NOT_A_NUMBER`;

        const result = normalizeTransactionsFromCsv(csv);

        expect(result[0].amount).toBe(0);
        expect(result[0].normalisation_notes).toEqual(
            expect.arrayContaining([expect.stringContaining('Invalid amount')])
        );
    });

    it('should add source file metadata if provided', () => {
        const csv = `Date,Description,Amount,Currency
2023-01-01,Test,10,EUR`;

        const result = normalizeTransactionsFromCsv(csv, { sourceFile: 'bank_stmt.csv' });

        expect(result[0].raw_source_file).toBe('bank_stmt.csv');
    });
});
