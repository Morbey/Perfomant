import { parse } from 'csv-parse/sync';
import { NormalisedTransaction, NormalizationOptions, TransactionDirection } from './types.js';

export function normalizeTransactionsFromCsv(
    csvContent: string,
    options: NormalizationOptions = {}
): NormalisedTransaction[] {
    const records = parse(csvContent, {
        columns: true,
        skip_empty_lines: true,
        trim: true,
    });

    return records.map((record: any, index: number) => {
        const notes: string[] = [];

        // 1. Amount & Direction
        let amountRaw = record['Amount'];
        // Remove currency symbols or commas if present (simple cleanup)
        if (typeof amountRaw === 'string') {
            amountRaw = amountRaw.replace(/[€$£,]/g, '');
        }

        let amount = parseFloat(amountRaw);
        let direction: TransactionDirection = 'credit';

        if (isNaN(amount)) {
            notes.push(`Invalid amount: ${record['Amount']}`);
            amount = 0;
        } else {
            if (amount < 0) {
                direction = 'debit';
                amount = Math.abs(amount);
            } else {
                direction = 'credit';
            }
        }

        // 2. Currency
        let currency = record['Currency'];
        if (!currency) {
            if (options.defaultCurrency) {
                currency = options.defaultCurrency;
                notes.push(`Used default currency: ${options.defaultCurrency}`);
            } else {
                currency = 'UNKNOWN';
                notes.push('Missing currency and no default provided');
            }
        }

        // 3. Date
        // Assuming standard format or passing through for now. 
        // Ideally we would normalize to YYYY-MM-DD here.
        const date = record['Date'] || '';

        // 4. Description
        const description = record['Description'] || '';

        // 5. Construct Object
        const transaction: NormalisedTransaction = {
            date,
            amount,
            direction,
            description,
            currency,
            raw_line_number: index + 2, // +1 for 0-index, +1 for header
        };

        if (options.sourceFile) {
            transaction.raw_source_file = options.sourceFile;
        }

        if (notes.length > 0) {
            transaction.normalisation_notes = notes;
        }

        // Optional fields from CSV if they exist
        if (record['Counterparty']) {
            transaction.counterparty = record['Counterparty'];
        }

        return transaction;
    });
}
